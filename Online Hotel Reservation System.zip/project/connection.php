<?php
$conn = new mysqli("localhost", "root","","managerooms") or die ("Failed to connect");
?>